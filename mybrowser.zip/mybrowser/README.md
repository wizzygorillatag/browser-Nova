# MyBrowser

A minimal tabbed desktop browser built with Electron.

## Run it
1. Install Node.js (https://nodejs.org), v18 or newer.
2. In this folder:
   ```
   npm install
   npm start
   ```

## Features
- Tabs (new, close, switch), favicons and page titles
- Back, forward, reload/stop, home
- Smart address bar: URLs open directly, anything else searches DuckDuckGo
- Links that open a new window become new tabs
- Shortcuts: Ctrl/Cmd+T new tab, Ctrl/Cmd+W close tab, Ctrl/Cmd+L focus address bar, Ctrl/Cmd+R reload, Ctrl+Tab next tab

## Build an installer (optional)
```
npm install --save-dev electron-builder
npx electron-builder
```

## Notes
Electron embeds Chromium, so this renders pages like Chrome does. It has no bookmarks, history, or extensions yet. Those would be the next things to add.
