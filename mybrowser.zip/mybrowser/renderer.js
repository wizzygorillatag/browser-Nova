const HOME = 'https://duckduckgo.com';
const SEARCH = 'https://duckduckgo.com/?q=';

const tabsEl = document.getElementById('tabs');
const viewsEl = document.getElementById('views');
const address = document.getElementById('address');
const backBtn = document.getElementById('back');
const forwardBtn = document.getElementById('forward');
const reloadBtn = document.getElementById('reload');

let tabs = [];       // { id, view, el, titleEl, faviconEl, loading }
let activeId = null;
let nextId = 1;

function normalize(input) {
  const text = input.trim();
  if (!text) return HOME;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;                 // already has a scheme
  if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?(\/.*)?$/i.test(text)) return 'http://' + text;
  if (!/\s/.test(text) && /\.[a-z]{2,}(:\d+)?(\/.*)?$/i.test(text)) return 'https://' + text;
  return SEARCH + encodeURIComponent(text);                               // otherwise search
}

function activeTab() { return tabs.find(t => t.id === activeId); }

function updateToolbar() {
  const tab = activeTab();
  if (!tab) return;
  let canBack = false, canForward = false;
  try { canBack = tab.view.canGoBack(); canForward = tab.view.canGoForward(); } catch {}
  backBtn.disabled = !canBack;
  forwardBtn.disabled = !canForward;
  reloadBtn.textContent = tab.loading ? '\u2715' : '\u21BB';
  if (document.activeElement !== address) {
    try { address.value = tab.view.getURL(); } catch {}
  }
}

function setActive(id) {
  activeId = id;
  tabs.forEach(t => {
    t.view.classList.toggle('active', t.id === id);
    t.el.classList.toggle('active', t.id === id);
  });
  const tab = activeTab();
  document.title = tab && tab.titleEl.textContent ? tab.titleEl.textContent + ' - MyBrowser' : 'MyBrowser';
  address.value = '';
  updateToolbar();
}

function createTab(url = HOME) {
  const id = nextId++;

  const view = document.createElement('webview');
  view.setAttribute('allowpopups', '');
  view.src = normalize(url);
  viewsEl.appendChild(view);

  const el = document.createElement('div');
  el.className = 'tab';
  el.innerHTML = '<img class="favicon" hidden><span class="title">New Tab</span><button class="close" title="Close tab">\u2715</button>';
  tabsEl.appendChild(el);

  const tab = {
    id, view, el, loading: false,
    titleEl: el.querySelector('.title'),
    faviconEl: el.querySelector('.favicon')
  };
  tabs.push(tab);

  el.addEventListener('mousedown', (e) => { if (e.target.className !== 'close') setActive(id); });
  el.querySelector('.close').addEventListener('click', (e) => { e.stopPropagation(); closeTab(id); });

  view.addEventListener('page-title-updated', (e) => {
    tab.titleEl.textContent = e.title;
    if (id === activeId) document.title = e.title + ' - MyBrowser';
  });
  view.addEventListener('page-favicon-updated', (e) => {
    if (e.favicons && e.favicons[0]) { tab.faviconEl.src = e.favicons[0]; tab.faviconEl.hidden = false; }
  });
  view.addEventListener('did-start-loading', () => { tab.loading = true; if (id === activeId) updateToolbar(); });
  view.addEventListener('did-stop-loading', () => { tab.loading = false; if (id === activeId) updateToolbar(); });
  const onNav = () => { if (id === activeId) { address.value = view.getURL(); updateToolbar(); } };
  view.addEventListener('did-navigate', onNav);
  view.addEventListener('did-navigate-in-page', onNav);

  setActive(id);
  if (url === HOME) address.focus();
  return tab;
}

function closeTab(id) {
  const idx = tabs.findIndex(t => t.id === id);
  if (idx === -1) return;
  const [tab] = tabs.splice(idx, 1);
  tab.view.remove();
  tab.el.remove();
  if (tabs.length === 0) { window.close(); return; }
  if (activeId === id) setActive(tabs[Math.min(idx, tabs.length - 1)].id);
}

// Toolbar
backBtn.onclick = () => { const t = activeTab(); if (t && t.view.canGoBack()) t.view.goBack(); };
forwardBtn.onclick = () => { const t = activeTab(); if (t && t.view.canGoForward()) t.view.goForward(); };
reloadBtn.onclick = () => { const t = activeTab(); if (!t) return; t.loading ? t.view.stop() : t.view.reload(); };
document.getElementById('home').onclick = () => { const t = activeTab(); if (t) t.view.loadURL(HOME); };
document.getElementById('new-tab').onclick = () => createTab();

address.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const t = activeTab();
    if (t) { t.view.loadURL(normalize(address.value)); t.view.focus(); }
  }
});
address.addEventListener('focus', () => address.select());
address.addEventListener('blur', updateToolbar);

// Keyboard shortcuts
window.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (!mod) return;
  const k = e.key.toLowerCase();
  if (k === 't') { e.preventDefault(); createTab(); }
  else if (k === 'w') { e.preventDefault(); closeTab(activeId); }
  else if (k === 'l') { e.preventDefault(); address.focus(); }
  else if (k === 'r') { e.preventDefault(); const t = activeTab(); if (t) t.view.reload(); }
  else if (k === 'tab') {
    e.preventDefault();
    const i = tabs.findIndex(t => t.id === activeId);
    setActive(tabs[(i + (e.shiftKey ? tabs.length - 1 : 1)) % tabs.length].id);
  }
});

// Links that open in a new window arrive from the main process
window.browserAPI.onOpenTab((url) => createTab(url));

createTab();
